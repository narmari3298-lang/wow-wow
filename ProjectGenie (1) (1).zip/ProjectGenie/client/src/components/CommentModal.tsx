import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface CommentModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (comment: string) => void;
  title: string;
  description: string;
  actionLabel: string;
}

export default function CommentModal({
  open,
  onClose,
  onSubmit,
  title,
  description,
  actionLabel,
}: CommentModalProps) {
  const [comment, setComment] = useState("");

  const handleSubmit = () => {
    if (comment.trim()) {
      onSubmit(comment);
      setComment("");
      onClose();
    }
  };

  const handleClose = () => {
    setComment("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent data-testid="modal-comment">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          <Label htmlFor="comment">Комментарий</Label>
          <Textarea
            id="comment"
            placeholder="Укажите причину или предложения по доработке..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={5}
            className="resize-none"
            data-testid="input-comment"
          />
          <p className="text-xs text-muted-foreground text-right">
            {comment.length} символов
          </p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} data-testid="button-cancel">
            Отмена
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!comment.trim()}
            data-testid="button-submit-comment"
          >
            {actionLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
