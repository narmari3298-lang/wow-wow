import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PlusCircle, Trash2, Upload, FileAudio, FileVideo } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ParticipantForm {
  id: string;
  name: string;
  position: string;
  organization: string;
}

interface TopicForm {
  id: string;
  title: string;
  summary: string;
}

interface TaskForm {
  id: string;
  title: string;
  assignee: string;
  deadline: string;
}

export default function CreateProtocolForm({ onSubmit }: { onSubmit?: () => void }) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("manual");
  
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [participants, setParticipants] = useState<ParticipantForm[]>([
    { id: "1", name: "", position: "", organization: "" },
  ]);
  const [topics, setTopics] = useState<TopicForm[]>([
    { id: "1", title: "", summary: "" },
  ]);
  const [tasks, setTasks] = useState<TaskForm[]>([
    { id: "1", title: "", assignee: "", deadline: "" },
  ]);

  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const addParticipant = () => {
    setParticipants([...participants, { id: Date.now().toString(), name: "", position: "", organization: "" }]);
  };

  const removeParticipant = (id: string) => {
    setParticipants(participants.filter(p => p.id !== id));
  };

  const addTopic = () => {
    setTopics([...topics, { id: Date.now().toString(), title: "", summary: "" }]);
  };

  const removeTopic = (id: string) => {
    setTopics(topics.filter(t => t.id !== id));
  };

  const addTask = () => {
    setTasks([...tasks, { id: Date.now().toString(), title: "", assignee: "", deadline: "" }]);
  };

  const removeTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      toast({
        title: "Файл загружен",
        description: `${file.name} готов к обработке`,
      });
    }
  };

  const handleProcessFile = () => {
    if (!uploadedFile) return;
    
    setIsProcessing(true);
    toast({
      title: "Обработка начата",
      description: "Создание транскрипции и протокола...",
    });

    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Протокол создан",
        description: "Автоматический протокол успешно сгенерирован",
      });
      onSubmit?.();
    }, 3000);
  };

  const handleManualSubmit = () => {
    toast({
      title: "Протокол создан",
      description: "Ваш протокол сохранен как черновик",
    });
    onSubmit?.();
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="manual" data-testid="tab-manual">Ручное создание</TabsTrigger>
          <TabsTrigger value="auto" data-testid="tab-auto">Загрузить запись</TabsTrigger>
        </TabsList>

        <TabsContent value="manual" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Основная информация</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Название встречи *</Label>
                <Input
                  id="title"
                  placeholder="Квартальное планирование"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  data-testid="input-title"
                />
              </div>

              <div>
                <Label htmlFor="date">Дата встречи *</Label>
                <Input
                  id="date"
                  type="datetime-local"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  data-testid="input-date"
                />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Участники</h3>
              <Button size="sm" onClick={addParticipant} data-testid="button-add-participant">
                <PlusCircle className="w-4 h-4 mr-2" />
                Добавить
              </Button>
            </div>

            <div className="space-y-4">
              {participants.map((participant, index) => (
                <div key={participant.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Участник {index + 1}</span>
                    {participants.length > 1 && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => removeParticipant(participant.id)}
                        data-testid={`button-remove-participant-${index}`}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid gap-3 md:grid-cols-3">
                    <div>
                      <Label>ФИО</Label>
                      <Input
                        placeholder="Иван Петров"
                        value={participant.name}
                        onChange={(e) => {
                          const updated = [...participants];
                          updated[index].name = e.target.value;
                          setParticipants(updated);
                        }}
                        data-testid={`input-participant-name-${index}`}
                      />
                    </div>
                    <div>
                      <Label>Должность</Label>
                      <Input
                        placeholder="Менеджер проекта"
                        value={participant.position}
                        onChange={(e) => {
                          const updated = [...participants];
                          updated[index].position = e.target.value;
                          setParticipants(updated);
                        }}
                        data-testid={`input-participant-position-${index}`}
                      />
                    </div>
                    <div>
                      <Label>Организация</Label>
                      <Input
                        placeholder="ООО Технологии"
                        value={participant.organization}
                        onChange={(e) => {
                          const updated = [...participants];
                          updated[index].organization = e.target.value;
                          setParticipants(updated);
                        }}
                        data-testid={`input-participant-org-${index}`}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Темы обсуждения</h3>
              <Button size="sm" onClick={addTopic} data-testid="button-add-topic">
                <PlusCircle className="w-4 h-4 mr-2" />
                Добавить
              </Button>
            </div>

            <div className="space-y-4">
              {topics.map((topic, index) => (
                <div key={topic.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Тема {index + 1}</span>
                    {topics.length > 1 && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => removeTopic(topic.id)}
                        data-testid={`button-remove-topic-${index}`}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                  
                  <div>
                    <Label>Название темы</Label>
                    <Input
                      placeholder="Обсуждение бюджета"
                      value={topic.title}
                      onChange={(e) => {
                        const updated = [...topics];
                        updated[index].title = e.target.value;
                        setTopics(updated);
                      }}
                      data-testid={`input-topic-title-${index}`}
                    />
                  </div>
                  
                  <div>
                    <Label>Краткое содержание</Label>
                    <Textarea
                      placeholder="Рассмотрены основные статьи расходов..."
                      value={topic.summary}
                      onChange={(e) => {
                        const updated = [...topics];
                        updated[index].summary = e.target.value;
                        setTopics(updated);
                      }}
                      rows={3}
                      data-testid={`input-topic-summary-${index}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Задачи</h3>
              <Button size="sm" onClick={addTask} data-testid="button-add-task">
                <PlusCircle className="w-4 h-4 mr-2" />
                Добавить
              </Button>
            </div>

            <div className="space-y-4">
              {tasks.map((task, index) => (
                <div key={task.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Задача {index + 1}</span>
                    {tasks.length > 1 && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => removeTask(task.id)}
                        data-testid={`button-remove-task-${index}`}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid gap-3 md:grid-cols-3">
                    <div className="md:col-span-2">
                      <Label>Описание задачи</Label>
                      <Input
                        placeholder="Подготовить отчет"
                        value={task.title}
                        onChange={(e) => {
                          const updated = [...tasks];
                          updated[index].title = e.target.value;
                          setTasks(updated);
                        }}
                        data-testid={`input-task-title-${index}`}
                      />
                    </div>
                    <div>
                      <Label>Срок</Label>
                      <Input
                        type="date"
                        value={task.deadline}
                        onChange={(e) => {
                          const updated = [...tasks];
                          updated[index].deadline = e.target.value;
                          setTasks(updated);
                        }}
                        data-testid={`input-task-deadline-${index}`}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label>Ответственный</Label>
                    <Input
                      placeholder="Иван Петров"
                      value={task.assignee}
                      onChange={(e) => {
                        const updated = [...tasks];
                        updated[index].assignee = e.target.value;
                        setTasks(updated);
                      }}
                      data-testid={`input-task-assignee-${index}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <div className="flex justify-end gap-3">
            <Button variant="outline" data-testid="button-cancel">Отмена</Button>
            <Button onClick={handleManualSubmit} data-testid="button-save-protocol">
              Сохранить протокол
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="auto" className="space-y-6">
          <Card className="p-8">
            <div className="text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              
              <div>
                <h3 className="font-semibold text-lg mb-2">Загрузите запись встречи</h3>
                <p className="text-sm text-muted-foreground">
                  Поддерживаются форматы: MP3, WAV, MP4, AVI (до 500 МБ)
                </p>
              </div>

              <div className="border-2 border-dashed rounded-lg p-8 hover-elevate cursor-pointer">
                <input
                  type="file"
                  accept="audio/*,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                  data-testid="input-file"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  {uploadedFile ? (
                    <div className="flex items-center justify-center gap-3">
                      {uploadedFile.type.startsWith('audio/') ? (
                        <FileAudio className="w-8 h-8 text-primary" />
                      ) : (
                        <FileVideo className="w-8 h-8 text-primary" />
                      )}
                      <div className="text-left">
                        <p className="font-medium">{uploadedFile.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(uploadedFile.size / 1024 / 1024).toFixed(2)} МБ
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="text-sm text-muted-foreground">
                        Нажмите для выбора файла или перетащите его сюда
                      </p>
                    </div>
                  )}
                </label>
              </div>

              {uploadedFile && (
                <Button
                  onClick={handleProcessFile}
                  disabled={isProcessing}
                  className="w-full"
                  data-testid="button-process-file"
                >
                  {isProcessing ? "Обработка..." : "Создать протокол"}
                </Button>
              )}
            </div>
          </Card>

          {isProcessing && (
            <Card className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Транскрибация аудио</span>
                  <span className="text-sm text-primary">60%</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary transition-all" style={{ width: "60%" }} />
                </div>
                <p className="text-sm text-muted-foreground">
                  Это может занять несколько минут в зависимости от длины записи...
                </p>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
