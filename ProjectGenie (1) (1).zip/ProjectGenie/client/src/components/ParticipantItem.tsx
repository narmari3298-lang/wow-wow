import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Building2, CheckCircle, Clock, XCircle } from "lucide-react";

export type ApprovalStatus = "pending" | "approved" | "rejected" | "revision";

export interface Participant {
  id: string;
  name: string;
  position: string;
  organization: string;
  approvalStatus?: ApprovalStatus;
  comment?: string;
}

interface ParticipantItemProps {
  participant: Participant;
  showApprovalStatus?: boolean;
}

const approvalConfig = {
  pending: { label: "Ожидает", icon: Clock, className: "bg-amber-100 text-amber-900 border-amber-200 dark:bg-amber-950 dark:text-amber-100" },
  approved: { label: "Согласовал", icon: CheckCircle, className: "bg-green-100 text-green-900 border-green-200 dark:bg-green-950 dark:text-green-100" },
  rejected: { label: "Отклонил", icon: XCircle, className: "bg-red-100 text-red-900 border-red-200 dark:bg-red-950 dark:text-red-100" },
  revision: { label: "На доработку", icon: Clock, className: "bg-orange-100 text-orange-900 border-orange-200 dark:bg-orange-950 dark:text-orange-100" },
};

export default function ParticipantItem({ participant, showApprovalStatus }: ParticipantItemProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const approvalInfo = participant.approvalStatus ? approvalConfig[participant.approvalStatus] : null;
  const ApprovalIcon = approvalInfo?.icon;

  return (
    <div className="flex items-start gap-3 p-4 rounded-lg border bg-card" data-testid={`participant-${participant.id}`}>
      <Avatar className="w-12 h-12">
        <AvatarFallback>{getInitials(participant.name)}</AvatarFallback>
      </Avatar>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h4 className="font-medium" data-testid={`text-participant-name-${participant.id}`}>
            {participant.name}
          </h4>
          {showApprovalStatus && approvalInfo && ApprovalIcon && (
            <Badge className={`gap-1.5 flex-shrink-0 ${approvalInfo.className}`}>
              <ApprovalIcon className="w-3 h-3" />
              {approvalInfo.label}
            </Badge>
          )}
        </div>
        
        <p className="text-sm text-muted-foreground mb-1">{participant.position}</p>
        
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Building2 className="w-3.5 h-3.5" />
          <span>{participant.organization}</span>
        </div>

        {participant.comment && (
          <div className="mt-3 p-3 bg-muted/50 rounded-md">
            <p className="text-sm text-foreground">{participant.comment}</p>
          </div>
        )}
      </div>
    </div>
  );
}
