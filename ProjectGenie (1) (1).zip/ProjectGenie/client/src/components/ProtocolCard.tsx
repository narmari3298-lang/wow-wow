import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, Users, MoreVertical } from "lucide-react";
import StatusBadge, { type ProtocolStatus } from "./StatusBadge";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export interface Protocol {
  id: string;
  title: string;
  date: Date;
  status: ProtocolStatus;
  participants: Array<{
    id: string;
    name: string;
    position: string;
  }>;
  approvalProgress?: {
    approved: number;
    total: number;
  };
}

interface ProtocolCardProps {
  protocol: Protocol;
  onView: (id: string) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

export default function ProtocolCard({ protocol, onView, onEdit, onDelete }: ProtocolCardProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const visibleParticipants = protocol.participants.slice(0, 4);
  const remainingCount = protocol.participants.length - 4;

  return (
    <Card
      className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all"
      onClick={() => onView(protocol.id)}
      data-testid={`card-protocol-${protocol.id}`}
    >
      <div className="flex items-start justify-between mb-4">
        <h3 className="font-semibold text-lg line-clamp-2 flex-1" data-testid={`text-protocol-title-${protocol.id}`}>
          {protocol.title}
        </h3>
        <div className="flex items-center gap-2 ml-2">
          <StatusBadge status={protocol.status} />
          {(onEdit || onDelete) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <Button size="icon" variant="ghost" data-testid={`button-menu-${protocol.id}`}>
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {onEdit && (
                  <DropdownMenuItem onClick={(e) => {
                    e.stopPropagation();
                    onEdit(protocol.id);
                  }} data-testid={`button-edit-${protocol.id}`}>
                    Редактировать
                  </DropdownMenuItem>
                )}
                {onDelete && (
                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(protocol.id);
                    }}
                    data-testid={`button-delete-${protocol.id}`}
                  >
                    Удалить
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
        <div className="flex items-center gap-1.5">
          <Calendar className="w-4 h-4" />
          <span data-testid={`text-protocol-date-${protocol.id}`}>
            {format(protocol.date, "d MMMM yyyy", { locale: ru })}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <Users className="w-4 h-4" />
          <span>{protocol.participants.length}</span>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex -space-x-2">
          {visibleParticipants.map((participant) => (
            <Avatar key={participant.id} className="w-8 h-8 border-2 border-background">
              <AvatarFallback className="text-xs">{getInitials(participant.name)}</AvatarFallback>
            </Avatar>
          ))}
          {remainingCount > 0 && (
            <Avatar className="w-8 h-8 border-2 border-background">
              <AvatarFallback className="text-xs bg-muted">+{remainingCount}</AvatarFallback>
            </Avatar>
          )}
        </div>

        {protocol.approvalProgress && protocol.status === "under_review" && (
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary transition-all"
                style={{
                  width: `${(protocol.approvalProgress.approved / protocol.approvalProgress.total) * 100}%`,
                }}
              />
            </div>
            <span className="text-xs text-muted-foreground">
              {protocol.approvalProgress.approved}/{protocol.approvalProgress.total}
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}
