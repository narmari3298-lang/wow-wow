import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import StatusBadge, { type ProtocolStatus } from "./StatusBadge";
import ParticipantItem, { type Participant } from "./ParticipantItem";
import TopicItem, { type Topic } from "./TopicItem";
import TaskItem, { type Task } from "./TaskItem";
import CommentModal from "./CommentModal";
import { Calendar, Clock, Edit, Trash2, Send, CheckCircle, XCircle, AlertCircle, ArrowLeft } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";

interface ProtocolDetailProps {
  protocol: {
    id: string;
    title: string;
    date: Date;
    duration?: string;
    status: ProtocolStatus;
    summary: string;
    participants: Participant[];
    topics: Topic[];
    tasks: Task[];
    isAuthor?: boolean;
  };
  onBack: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
}

export default function ProtocolDetail({ protocol, onBack, onEdit, onDelete }: ProtocolDetailProps) {
  const { toast } = useToast();
  const [modalState, setModalState] = useState<{
    open: boolean;
    type: "reject" | "revision" | null;
  }>({ open: false, type: null });

  const canEdit = protocol.isAuthor && protocol.status !== "published";
  const canPublish = protocol.isAuthor && protocol.status === "approved";
  const canApprove = !protocol.isAuthor && protocol.status === "under_review";

  const handleApprove = () => {
    toast({
      title: "Протокол согласован",
      description: "Ваше решение отправлено автору",
    });
  };

  const handleReject = (comment: string) => {
    toast({
      title: "Протокол отклонен",
      description: "Ваш комментарий отправлен автору",
    });
  };

  const handleRevision = (comment: string) => {
    toast({
      title: "Отправлено на доработку",
      description: "Автор получит ваши замечания",
    });
  };

  const handlePublish = () => {
    toast({
      title: "Протокол опубликован",
      description: "Протокол доступен всем участникам",
    });
  };

  const handleSendForReview = () => {
    toast({
      title: "Отправлено на согласование",
      description: "Участники получили уведомление",
    });
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-6">
        <Button variant="ghost" onClick={onBack} className="mb-4" data-testid="button-back">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Назад к списку
        </Button>

        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex-1 min-w-0">
            <h1 className="text-3xl font-bold mb-3" data-testid="text-protocol-title">
              {protocol.title}
            </h1>
            <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                <span>{format(protocol.date, "d MMMM yyyy", { locale: ru })}</span>
              </div>
              {protocol.duration && (
                <div className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4" />
                  <span>{protocol.duration}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <StatusBadge status={protocol.status} />
            {canEdit && onEdit && (
              <Button variant="outline" onClick={onEdit} data-testid="button-edit">
                <Edit className="w-4 h-4 mr-2" />
                Редактировать
              </Button>
            )}
            {canEdit && onDelete && (
              <Button variant="outline" onClick={onDelete} data-testid="button-delete">
                <Trash2 className="w-4 h-4 mr-2 text-destructive" />
                Удалить
              </Button>
            )}
          </div>
        </div>
      </div>

      {canApprove && (
        <Card className="p-6 mb-6 bg-primary/5 border-primary/20">
          <h3 className="font-semibold mb-3">Требуется ваше решение</h3>
          <div className="flex gap-3 flex-wrap">
            <Button onClick={handleApprove} data-testid="button-approve">
              <CheckCircle className="w-4 h-4 mr-2" />
              Согласовать
            </Button>
            <Button
              variant="outline"
              onClick={() => setModalState({ open: true, type: "revision" })}
              data-testid="button-request-revision"
            >
              <AlertCircle className="w-4 h-4 mr-2" />
              Отправить на доработку
            </Button>
            <Button
              variant="outline"
              onClick={() => setModalState({ open: true, type: "reject" })}
              data-testid="button-reject"
            >
              <XCircle className="w-4 h-4 mr-2 text-destructive" />
              Отклонить
            </Button>
          </div>
        </Card>
      )}

      {protocol.status === "draft" && protocol.isAuthor && (
        <Card className="p-6 mb-6 bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900">
          <h3 className="font-semibold mb-3">Черновик готов</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Отправьте протокол на согласование участникам встречи
          </p>
          <Button onClick={handleSendForReview} data-testid="button-send-review">
            <Send className="w-4 h-4 mr-2" />
            Отправить на согласование
          </Button>
        </Card>
      )}

      {canPublish && (
        <Card className="p-6 mb-6 bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-900">
          <h3 className="font-semibold mb-3">Готово к публикации</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Все участники согласовали протокол. Вы можете опубликовать его.
          </p>
          <Button onClick={handlePublish} data-testid="button-publish">
            <CheckCircle className="w-4 h-4 mr-2" />
            Опубликовать протокол
          </Button>
        </Card>
      )}

      <div className="space-y-6">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Резюме встречи</h2>
          <p className="text-muted-foreground leading-relaxed">{protocol.summary}</p>
        </Card>

        <div>
          <h2 className="text-xl font-semibold mb-4">Участники ({protocol.participants.length})</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {protocol.participants.map((participant) => (
              <ParticipantItem
                key={participant.id}
                participant={participant}
                showApprovalStatus={protocol.status !== "draft"}
              />
            ))}
          </div>
        </div>

        <Separator />

        <div>
          <h2 className="text-xl font-semibold mb-4">Темы обсуждения ({protocol.topics.length})</h2>
          <div className="space-y-3">
            {protocol.topics.map((topic, index) => (
              <TopicItem key={topic.id} topic={topic} index={index} />
            ))}
          </div>
        </div>

        <Separator />

        <div>
          <h2 className="text-xl font-semibold mb-4">Задачи ({protocol.tasks.length})</h2>
          <div className="space-y-3">
            {protocol.tasks.map((task) => (
              <TaskItem key={task.id} task={task} />
            ))}
          </div>
        </div>
      </div>

      <CommentModal
        open={modalState.open}
        onClose={() => setModalState({ open: false, type: null })}
        onSubmit={(comment) => {
          if (modalState.type === "reject") {
            handleReject(comment);
          } else if (modalState.type === "revision") {
            handleRevision(comment);
          }
        }}
        title={modalState.type === "reject" ? "Отклонить протокол" : "Отправить на доработку"}
        description={
          modalState.type === "reject"
            ? "Пожалуйста, укажите причину отклонения протокола"
            : "Пожалуйста, укажите, что необходимо доработать"
        }
        actionLabel={modalState.type === "reject" ? "Отклонить" : "Отправить"}
      />
    </div>
  );
}
