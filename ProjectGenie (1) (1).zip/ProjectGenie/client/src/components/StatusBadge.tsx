import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, XCircle, AlertCircle, Sparkles } from "lucide-react";

export type ProtocolStatus = "draft" | "under_review" | "approved" | "rejected" | "published";

interface StatusBadgeProps {
  status: ProtocolStatus;
  className?: string;
}

const statusConfig = {
  draft: {
    label: "Черновик",
    icon: AlertCircle,
    variant: "secondary" as const,
  },
  under_review: {
    label: "На согласовании",
    icon: Clock,
    variant: "default" as const,
  },
  approved: {
    label: "Согласован",
    icon: CheckCircle,
    variant: "default" as const,
  },
  rejected: {
    label: "Отклонен",
    icon: XCircle,
    variant: "destructive" as const,
  },
  published: {
    label: "Опубликован",
    icon: Sparkles,
    variant: "default" as const,
  },
};

const statusStyles = {
  draft: "bg-muted text-muted-foreground border-muted-border",
  under_review: "bg-amber-100 text-amber-900 border-amber-200 dark:bg-amber-950 dark:text-amber-100 dark:border-amber-900",
  approved: "bg-green-100 text-green-900 border-green-200 dark:bg-green-950 dark:text-green-100 dark:border-green-900",
  rejected: "bg-red-100 text-red-900 border-red-200 dark:bg-red-950 dark:text-red-100 dark:border-red-900",
  published: "bg-primary/10 text-primary border-primary/20",
};

export default function StatusBadge({ status, className = "" }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <Badge className={`gap-1.5 ${statusStyles[status]} ${className}`} data-testid={`badge-status-${status}`}>
      <Icon className="w-3 h-3" />
      {config.label}
    </Badge>
  );
}
