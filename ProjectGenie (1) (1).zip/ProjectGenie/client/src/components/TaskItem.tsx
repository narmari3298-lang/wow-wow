import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export interface Task {
  id: string;
  title: string;
  description?: string;
  assignee: {
    id: string;
    name: string;
  };
  deadline?: Date;
  status: "pending" | "completed";
}

interface TaskItemProps {
  task: Task;
}

export default function TaskItem({ task }: TaskItemProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const isOverdue = task.deadline && task.status === "pending" && task.deadline < new Date();

  return (
    <Card className="p-4" data-testid={`task-${task.id}`}>
      <div className="flex items-start gap-3">
        <div className={`flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 ${
          task.status === "completed" ? "bg-green-500 border-green-500" : "border-muted-foreground"
        }`}>
          {task.status === "completed" && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
        </div>

        <div className="flex-1 min-w-0">
          <h4 className={`font-medium mb-1 ${task.status === "completed" ? "line-through text-muted-foreground" : ""}`} data-testid={`text-task-title-${task.id}`}>
            {task.title}
          </h4>
          
          {task.description && (
            <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
          )}

          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback className="text-xs">{getInitials(task.assignee.name)}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-muted-foreground">{task.assignee.name}</span>
            </div>

            {task.deadline && (
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                <span className={`text-sm ${isOverdue ? "text-destructive font-medium" : "text-muted-foreground"}`}>
                  {format(task.deadline, "d MMMM", { locale: ru })}
                </span>
                {isOverdue && <Badge variant="destructive" className="text-xs">Просрочено</Badge>}
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
