import { Card } from "@/components/ui/card";
import { MessageSquare } from "lucide-react";

export interface Topic {
  id: string;
  title: string;
  summary: string;
}

interface TopicItemProps {
  topic: Topic;
  index: number;
}

export default function TopicItem({ topic, index }: TopicItemProps) {
  return (
    <Card className="p-4" data-testid={`topic-${topic.id}`}>
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
          <span className="text-sm font-semibold text-primary">{index + 1}</span>
        </div>
        
        <div className="flex-1 min-w-0">
          <h4 className="font-medium mb-2 flex items-center gap-2" data-testid={`text-topic-title-${topic.id}`}>
            <MessageSquare className="w-4 h-4 text-muted-foreground" />
            {topic.title}
          </h4>
          <p className="text-sm text-muted-foreground leading-relaxed">{topic.summary}</p>
        </div>
      </div>
    </Card>
  );
}
