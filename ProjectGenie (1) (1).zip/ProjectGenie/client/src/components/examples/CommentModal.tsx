import { useState } from 'react';
import CommentModal from '../CommentModal';
import { Button } from '@/components/ui/button';

export default function CommentModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <Button onClick={() => setOpen(true)}>Открыть модальное окно</Button>
      <CommentModal
        open={open}
        onClose={() => setOpen(false)}
        onSubmit={(comment) => console.log('Comment submitted:', comment)}
        title="Отправить на доработку"
        description="Пожалуйста, укажите причину отправки протокола на доработку"
        actionLabel="Отправить"
      />
    </div>
  );
}
