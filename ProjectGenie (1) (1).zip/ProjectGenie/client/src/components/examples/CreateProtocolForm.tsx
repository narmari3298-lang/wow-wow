import CreateProtocolForm from '../CreateProtocolForm';

export default function CreateProtocolFormExample() {
  return <CreateProtocolForm onSubmit={() => console.log('Protocol created')} />;
}
