import ParticipantItem from '../ParticipantItem';

export default function ParticipantItemExample() {
  const mockParticipants = [
    {
      id: "1",
      name: "Иван Петров",
      position: "Руководитель проекта",
      organization: "ООО Технологии",
      approvalStatus: "approved" as const,
    },
    {
      id: "2",
      name: "Мария Сидорова",
      position: "Бизнес-аналитик",
      organization: "ООО Технологии",
      approvalStatus: "revision" as const,
      comment: "Необходимо уточнить сроки выполнения задач по внедрению новой системы"
    },
  ];

  return (
    <div className="max-w-2xl space-y-3">
      {mockParticipants.map(participant => (
        <ParticipantItem key={participant.id} participant={participant} showApprovalStatus />
      ))}
    </div>
  );
}
