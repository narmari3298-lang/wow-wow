import ProtocolCard from '../ProtocolCard';

export default function ProtocolCardExample() {
  const mockProtocol = {
    id: "1",
    title: "Планирование квартального спринта",
    date: new Date(2024, 10, 15),
    status: "under_review" as const,
    participants: [
      { id: "1", name: "Иван Петров", position: "Руководитель проекта" },
      { id: "2", name: "Мария Сидорова", position: "Аналитик" },
      { id: "3", name: "Алексей Смирнов", position: "Разработчик" },
      { id: "4", name: "Елена Козлова", position: "Дизайнер" },
      { id: "5", name: "Дмитрий Новиков", position: "Тестировщик" },
    ],
    approvalProgress: {
      approved: 3,
      total: 5,
    },
  };

  return (
    <div className="max-w-md">
      <ProtocolCard
        protocol={mockProtocol}
        onView={(id) => console.log('View protocol:', id)}
        onEdit={(id) => console.log('Edit protocol:', id)}
        onDelete={(id) => console.log('Delete protocol:', id)}
      />
    </div>
  );
}
