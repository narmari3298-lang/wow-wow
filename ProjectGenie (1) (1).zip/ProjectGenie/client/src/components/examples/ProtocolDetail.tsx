import ProtocolDetail from '../ProtocolDetail';

export default function ProtocolDetailExample() {
  const mockProtocol = {
    id: "1",
    title: "Планирование квартального спринта",
    date: new Date(2024, 10, 15),
    duration: "1ч 30мин",
    status: "under_review" as const,
    summary: "Обсудили планы на следующий квартал, определили ключевые приоритеты и распределили задачи между командами. Рассмотрены вопросы бюджетирования и необходимые ресурсы для выполнения поставленных целей.",
    participants: [
      {
        id: "1",
        name: "Иван Петров",
        position: "Руководитель проекта",
        organization: "ООО Технологии",
        approvalStatus: "approved" as const,
      },
      {
        id: "2",
        name: "Мария Сидорова",
        position: "Бизнес-аналитик",
        organization: "ООО Технологии",
        approvalStatus: "pending" as const,
      },
      {
        id: "3",
        name: "Алексей Смирнов",
        position: "Ведущий разработчик",
        organization: "ООО Технологии",
        approvalStatus: "revision" as const,
        comment: "Необходимо уточнить сроки по внедрению новой системы аналитики",
      },
    ],
    topics: [
      {
        id: "1",
        title: "Обсуждение бюджета на следующий квартал",
        summary: "Рассмотрены основные статьи расходов и необходимость увеличения бюджета на маркетинг на 15%"
      },
      {
        id: "2",
        title: "Планирование новых функций продукта",
        summary: "Определены приоритеты для внедрения новых возможностей на основе обратной связи клиентов"
      },
    ],
    tasks: [
      {
        id: "1",
        title: "Подготовить презентацию для совета директоров",
        description: "Включить данные по продажам за квартал и прогноз на следующий период",
        assignee: { id: "1", name: "Иван Петров" },
        deadline: new Date(2024, 11, 20),
        status: "pending" as const,
      },
      {
        id: "2",
        title: "Провести тестирование новой функции",
        assignee: { id: "2", name: "Мария Сидорова" },
        deadline: new Date(2024, 10, 25),
        status: "pending" as const,
      },
    ],
    isAuthor: false,
  };

  return (
    <ProtocolDetail
      protocol={mockProtocol}
      onBack={() => console.log('Back clicked')}
      onEdit={() => console.log('Edit clicked')}
      onDelete={() => console.log('Delete clicked')}
    />
  );
}
