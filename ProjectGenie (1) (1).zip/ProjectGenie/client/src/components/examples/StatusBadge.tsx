import StatusBadge from '../StatusBadge';

export default function StatusBadgeExample() {
  return (
    <div className="flex flex-wrap gap-3">
      <StatusBadge status="draft" />
      <StatusBadge status="under_review" />
      <StatusBadge status="approved" />
      <StatusBadge status="rejected" />
      <StatusBadge status="published" />
    </div>
  );
}
