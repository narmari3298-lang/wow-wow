import TaskItem from '../TaskItem';

export default function TaskItemExample() {
  const mockTasks = [
    {
      id: "1",
      title: "Подготовить презентацию для совета директоров",
      description: "Включить данные по продажам за квартал и прогноз на следующий период",
      assignee: { id: "1", name: "Иван Петров" },
      deadline: new Date(2024, 11, 20),
      status: "pending" as const,
    },
    {
      id: "2",
      title: "Провести тестирование новой функции",
      assignee: { id: "2", name: "Мария Сидорова" },
      deadline: new Date(2024, 10, 10),
      status: "completed" as const,
    },
  ];

  return (
    <div className="max-w-2xl space-y-3">
      {mockTasks.map(task => (
        <TaskItem key={task.id} task={task} />
      ))}
    </div>
  );
}
