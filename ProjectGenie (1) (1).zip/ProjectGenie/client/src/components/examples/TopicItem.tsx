import TopicItem from '../TopicItem';

export default function TopicItemExample() {
  const mockTopics = [
    {
      id: "1",
      title: "Обсуждение бюджета на следующий квартал",
      summary: "Рассмотрены основные статьи расходов и необходимость увеличения бюджета на маркетинг на 15%"
    },
    {
      id: "2",
      title: "Планирование новых функций продукта",
      summary: "Определены приоритеты для внедрения новых возможностей на основе обратной связи клиентов"
    },
  ];

  return (
    <div className="max-w-2xl space-y-3">
      {mockTopics.map((topic, index) => (
        <TopicItem key={topic.id} topic={topic} index={index} />
      ))}
    </div>
  );
}
