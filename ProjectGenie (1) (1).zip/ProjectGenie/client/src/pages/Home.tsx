import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, FileText } from "lucide-react";
import ProtocolCard, { type Protocol } from "@/components/ProtocolCard";
import ProtocolDetail from "@/components/ProtocolDetail";
import CreateProtocolForm from "@/components/CreateProtocolForm";

export default function Home() {
  const [view, setView] = useState<"list" | "detail" | "create">("list");
  const [selectedProtocolId, setSelectedProtocolId] = useState<string | null>(null);

  const mockProtocols: Protocol[] = [
    {
      id: "1",
      title: "Планирование квартального спринта Q4 2024",
      date: new Date(2024, 10, 15),
      status: "under_review",
      participants: [
        { id: "1", name: "Иван Петров", position: "Руководитель проекта" },
        { id: "2", name: "Мария Сидорова", position: "Аналитик" },
        { id: "3", name: "Алексей Смирнов", position: "Разработчик" },
        { id: "4", name: "Елена Козлова", position: "Дизайнер" },
        { id: "5", name: "Дмитрий Новиков", position: "Тестировщик" },
      ],
      approvalProgress: { approved: 3, total: 5 },
    },
    {
      id: "2",
      title: "Обсуждение новой маркетинговой стратегии",
      date: new Date(2024, 10, 12),
      status: "approved",
      participants: [
        { id: "1", name: "Ольга Иванова", position: "Директор по маркетингу" },
        { id: "2", name: "Сергей Волков", position: "Маркетолог" },
        { id: "3", name: "Анна Федорова", position: "SMM-менеджер" },
      ],
    },
    {
      id: "3",
      title: "Еженедельный стендап команды разработки",
      date: new Date(2024, 10, 10),
      status: "published",
      participants: [
        { id: "1", name: "Алексей Смирнов", position: "Ведущий разработчик" },
        { id: "2", name: "Дмитрий Новиков", position: "Тестировщик" },
        { id: "3", name: "Мария Сидорова", position: "Аналитик" },
      ],
    },
    {
      id: "4",
      title: "Презентация результатов Q3",
      date: new Date(2024, 9, 28),
      status: "draft",
      participants: [
        { id: "1", name: "Иван Петров", position: "CEO" },
        { id: "2", name: "Ольга Иванова", position: "Директор по маркетингу" },
      ],
    },
  ];

  const mockDetailProtocol = {
    id: "1",
    title: "Планирование квартального спринта Q4 2024",
    date: new Date(2024, 10, 15),
    duration: "1ч 30мин",
    status: "under_review" as const,
    summary: "Обсудили планы на следующий квартал, определили ключевые приоритеты и распределили задачи между командами. Рассмотрены вопросы бюджетирования и необходимые ресурсы для выполнения поставленных целей.",
    participants: [
      {
        id: "1",
        name: "Иван Петров",
        position: "Руководитель проекта",
        organization: "ООО Технологии",
        approvalStatus: "approved" as const,
      },
      {
        id: "2",
        name: "Мария Сидорова",
        position: "Бизнес-аналитик",
        organization: "ООО Технологии",
        approvalStatus: "pending" as const,
      },
      {
        id: "3",
        name: "Алексей Смирнов",
        position: "Ведущий разработчик",
        organization: "ООО Технологии",
        approvalStatus: "revision" as const,
        comment: "Необходимо уточнить сроки по внедрению новой системы аналитики",
      },
      {
        id: "4",
        name: "Елена Козлова",
        position: "Дизайнер UI/UX",
        organization: "ООО Технологии",
        approvalStatus: "approved" as const,
      },
      {
        id: "5",
        name: "Дмитрий Новиков",
        position: "QA инженер",
        organization: "ООО Технологии",
        approvalStatus: "approved" as const,
      },
    ],
    topics: [
      {
        id: "1",
        title: "Обсуждение бюджета на следующий квартал",
        summary: "Рассмотрены основные статьи расходов и необходимость увеличения бюджета на маркетинг на 15%. Утверждены дополнительные средства на привлечение новых клиентов."
      },
      {
        id: "2",
        title: "Планирование новых функций продукта",
        summary: "Определены приоритеты для внедрения новых возможностей на основе обратной связи клиентов. В приоритете - улучшение мобильного приложения."
      },
      {
        id: "3",
        title: "Распределение ролей в команде",
        summary: "Назначены ответственные за каждое направление. Обсуждены области взаимодействия между отделами."
      },
    ],
    tasks: [
      {
        id: "1",
        title: "Подготовить презентацию для совета директоров",
        description: "Включить данные по продажам за квартал и прогноз на следующий период",
        assignee: { id: "1", name: "Иван Петров" },
        deadline: new Date(2024, 11, 20),
        status: "pending" as const,
      },
      {
        id: "2",
        title: "Провести тестирование новой функции",
        assignee: { id: "5", name: "Дмитрий Новиков" },
        deadline: new Date(2024, 10, 25),
        status: "pending" as const,
      },
      {
        id: "3",
        title: "Обновить дизайн главной страницы",
        assignee: { id: "4", name: "Елена Козлова" },
        deadline: new Date(2024, 10, 30),
        status: "completed" as const,
      },
    ],
    isAuthor: false,
  };

  const myProtocols = mockProtocols.filter(p => p.id === "1" || p.id === "4");
  const participatingProtocols = mockProtocols.filter(p => p.id === "2" || p.id === "3");

  const handleViewProtocol = (id: string) => {
    setSelectedProtocolId(id);
    setView("detail");
  };

  const handleCreateNew = () => {
    setView("create");
  };

  const handleBack = () => {
    setView("list");
    setSelectedProtocolId(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/50 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">AI Секретарь</h1>
                <p className="text-xs text-muted-foreground">Управление протоколами встреч</p>
              </div>
            </div>

            {view === "list" && (
              <Button onClick={handleCreateNew} data-testid="button-create-protocol">
                <PlusCircle className="w-4 h-4 mr-2" />
                Создать протокол
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {view === "list" && (
          <Tabs defaultValue="my" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="my" data-testid="tab-my-protocols">
                Мои протоколы ({myProtocols.length})
              </TabsTrigger>
              <TabsTrigger value="participating" data-testid="tab-participating">
                Участвую ({participatingProtocols.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="my" className="space-y-6">
              {myProtocols.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Нет протоколов</h3>
                  <p className="text-muted-foreground mb-6">
                    Создайте свой первый протокол встречи
                  </p>
                  <Button onClick={handleCreateNew}>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Создать протокол
                  </Button>
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {myProtocols.map((protocol) => (
                    <ProtocolCard
                      key={protocol.id}
                      protocol={protocol}
                      onView={handleViewProtocol}
                      onEdit={(id) => console.log("Edit", id)}
                      onDelete={(id) => console.log("Delete", id)}
                    />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="participating" className="space-y-6">
              {participatingProtocols.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Нет протоколов</h3>
                  <p className="text-muted-foreground">
                    Вы пока не участвуете ни в одном протоколе
                  </p>
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {participatingProtocols.map((protocol) => (
                    <ProtocolCard
                      key={protocol.id}
                      protocol={protocol}
                      onView={handleViewProtocol}
                    />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}

        {view === "detail" && (
          <ProtocolDetail
            protocol={mockDetailProtocol}
            onBack={handleBack}
            onEdit={() => console.log("Edit")}
            onDelete={() => console.log("Delete")}
          />
        )}

        {view === "create" && (
          <div>
            <Button variant="ghost" onClick={handleBack} className="mb-6" data-testid="button-back-create">
              ← Назад
            </Button>
            <h2 className="text-2xl font-bold mb-6">Создать новый протокол</h2>
            <CreateProtocolForm onSubmit={handleBack} />
          </div>
        )}
      </main>
    </div>
  );
}
