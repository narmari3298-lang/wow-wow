# AI Secretary - Design Guidelines

## Design Approach
**Utility-Focused Productivity Application** - Drawing inspiration from Linear, Notion, and modern productivity tools with emphasis on clarity, workflow efficiency, and status-driven interfaces.

## Typography
- **Primary Font**: Inter or Poppins (Google Fonts)
- **Hierarchy**:
  - H1: 2xl/3xl - Protocol titles, page headers
  - H2: xl - Section headers, card titles
  - H3: lg - Subsections, participant names
  - Body: base - Main content, descriptions
  - Small: sm - Metadata, timestamps, secondary info
- **Weights**: Regular (400) for body, Medium (500) for emphasis, SemiBold (600) for headings

## Layout System
- **Spacing primitives**: Tailwind units of 2, 4, 6, 8, 12, 16
- **Container**: max-w-7xl with px-4/6/8 responsive padding
- **Grid**: 1 column mobile, 2-3 columns tablet/desktop for protocol cards

## Core Components

### Navigation
- Fixed top navigation bar with app logo/name
- User profile indicator (top-right)
- Tab-based navigation: "My Protocols" | "Participating In" | "Create New"
- Mobile: Hamburger menu collapsing to drawer

### Protocol Cards (Dashboard View)
- Card-based grid layout (gap-6)
- Each card shows:
  - Status badge (top-right corner): Draft | Under Review | Approved | Rejected | Published
  - Meeting title (bold, truncated)
  - Date/time (small, muted)
  - Participant avatars (overlapping circles, max 4 visible + count)
  - Approval progress bar (for Under Review status)
  - Quick action menu (three-dot icon)

### Protocol Detail View
- **Header Section**:
  - Large meeting title
  - Status badge
  - Date, time, duration metadata
  - Action buttons (Edit/Publish/Delete for author; Approve/Reject/Request Revision for participants)

- **Content Sections** (vertical stack with dividers):
  - Meeting Summary (expandable text block)
  - Participants List (cards with avatar, name, position, organization, approval status badge, comment if any)
  - Topics Discussed (numbered list with topic title + brief summary in nested card)
  - Action Items/Tasks (checklist-style cards with assignee, deadline, status)

### Forms (Create/Edit Protocol)
- **Two-tab interface**: "Manual Entry" | "Upload Recording"
- **Manual Entry**: Vertical form with labeled inputs, add/remove buttons for dynamic fields (participants, topics, tasks)
- **Upload Recording**: Large drag-drop zone with file icon, progress bar during upload, transcription preview area

### Modals
- **Rejection/Revision Comment Modal**:
  - Centered overlay with backdrop blur
  - Textarea for comment (required)
  - Character counter
  - Cancel/Submit buttons (Submit disabled until text entered)

### Status System
- **Visual indicators**:
  - Draft: Gray outline badge
  - Under Review: Yellow/amber badge with clock icon
  - Approved: Green badge with checkmark
  - Rejected: Red badge with X icon
  - Published: Purple/lavender badge with star icon

## Animations
- Card hover: subtle lift (translateY -2px, shadow increase)
- Status transitions: gentle fade + scale animation
- Modal entrance: fade-in backdrop + slide-up content
- Button clicks: quick scale down/up (active state)
- Protocol card addition: slide-in from bottom with fade

## Icons
**Font Awesome (via CDN)** - Use regular and solid variants:
- Users, calendar, clock for metadata
- Check-circle, times-circle, edit for actions
- Upload, file-audio, file-video for recording features
- Comment, bell for notifications
- Bars for mobile menu

## Component Library

### Buttons
- **Primary**: Lavender background, white text, rounded corners (rounded-lg)
- **Secondary**: White background, lavender border, lavender text
- **Danger**: Red variant for delete/reject actions
- **Sizes**: Small (py-2 px-4), Medium (py-3 px-6), Large (py-4 px-8)

### Input Fields
- Border style, rounded corners (rounded-md)
- Focus state: lavender border highlight
- Label above input (text-sm, medium weight)
- Helper text below (text-xs, muted)

### Badges
- Pill-shaped (rounded-full), small padding (px-3 py-1)
- Icon + text combination when relevant
- Color-coded by status type

### Cards
- White background with subtle shadow
- Rounded corners (rounded-xl)
- Padding p-6
- Hover state: shadow elevation increase

## Mobile Considerations
- Stack all multi-column layouts to single column
- Larger tap targets (min 44px height)
- Bottom action bar for primary actions in detail view
- Swipe gestures for card actions
- Collapsible sections for long content

## Accessibility
- Consistent focus indicators (2px lavender ring)
- ARIA labels for icon-only buttons
- Sufficient contrast ratios (WCAG AA minimum)
- Keyboard navigation support throughout